/**
 * Hamster Wheel Adventure - SqueekChain Community Edition
 */

import { useState, useEffect, useCallback } from 'react';
import {
  GameState,
  GameMode,
  LevelConfig,
  HamsterSkin,
  PowerUpState,
  PlayerStats,
  Achievement,
  LeaderboardEntry,
} from './types/game';
import {
  loadPlayerStats,
  savePlayerStats,
  loadLevels,
  saveLevels,
  loadAchievements,
  saveAchievements,
  loadLeaderboard,
  INITIAL_SKINS,
} from './utils/storage';
import { audio } from './utils/audio';
import { GameCanvas } from './components/GameCanvas';
import { GameHUD } from './components/GameHUD';
import { TitleScreen } from './components/TitleScreen';
import { LevelSelectModal } from './components/LevelSelectModal';
import { LockerModal } from './components/LockerModal';
import { LeaderboardModal } from './components/LeaderboardModal';
import { AchievementsModal } from './components/AchievementsModal';
import { GameOverModal } from './components/GameOverModal';
import { VictoryModal } from './components/VictoryModal';
import { PauseModal } from './components/PauseModal';
import { Coins, Play } from 'lucide-react';

export default function App() {
  // Persistent data state
  const [stats, setStats] = useState<PlayerStats>(loadPlayerStats);
  const [levels, setLevels] = useState<LevelConfig[]>(loadLevels);
  const [achievements, setAchievements] = useState<Achievement[]>(loadAchievements);
  const [allSkins, setAllSkins] = useState<HamsterSkin[]>(() => {
    const saved = loadPlayerStats();
    return INITIAL_SKINS.map((s) => ({
      ...s,
      unlocked: saved.unlockedSkins.includes(s.id),
    }));
  });
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>(() => loadLeaderboard());

  // Game flow state
  const [gameState, setGameState] = useState<GameState>('TITLE_MENU');
  const [gameMode, setGameMode] = useState<GameMode>('LEVELS');
  const [currentLevelId, setCurrentLevelId] = useState<number>(1);
  const [isPaused, setIsPaused] = useState<boolean>(false);

  // Active game run session metrics
  const [currentScore, setCurrentScore] = useState<number>(0);
  const [currentCoins, setCurrentCoins] = useState<number>(0);
  const [currentDistance, setCurrentDistance] = useState<number>(0);
  const [currentCombo, setCurrentCombo] = useState<number>(1);
  const [powerUps, setPowerUps] = useState<PowerUpState>({
    magnet: 0,
    energyBoost: 0,
    shield: false,
    doubleCoins: 0,
  });

  // End run results
  const [lastRunStats, setLastRunStats] = useState<{
    score: number;
    distance: number;
    coins: number;
    comboPeak: number;
    isNewHighScore: boolean;
  }>({ score: 0, distance: 0, coins: 0, comboPeak: 1, isNewHighScore: false });

  const [lastVictoryStats, setLastVictoryStats] = useState<{
    score: number;
    distance: number;
    coins: number;
    stars: number;
  }>({ score: 0, distance: 0, coins: 0, stars: 1 });

  // Sync sound settings with audio manager
  useEffect(() => {
    audio.setSoundEnabled(stats.soundEnabled);
    audio.setMusicEnabled(stats.musicEnabled);
  }, [stats.soundEnabled, stats.musicEnabled]);

  // Current level and skin helpers
  const currentLevel = levels.find((l) => l.id === currentLevelId) || levels[0];
  const currentSkin = allSkins.find((s) => s.id === stats.selectedSkin) || allSkins[0];

  // Helper to update and save stats
  const updateStats = useCallback((updater: (prev: PlayerStats) => PlayerStats) => {
    setStats((prev) => {
      const next = updater(prev);
      savePlayerStats(next);
      return next;
    });
  }, []);

  // Update achievements helper
  const checkAchievements = useCallback(
    (action: {
      type: 'run_started' | 'distance' | 'coins' | 'combo' | 'double_jump' | 'beat_level';
      value?: number;
      levelId?: number;
    }) => {
      setAchievements((prev) => {
        let modified = false;
        const next = prev.map((ach) => {
          let progress = ach.progress;

          if (action.type === 'run_started' && ach.id === 'first_run') {
            progress = Math.max(progress, 1);
          } else if (action.type === 'distance') {
            if (ach.id === 'distance_500') progress = Math.max(progress, action.value || 0);
            if (ach.id === 'distance_1500') progress = Math.max(progress, action.value || 0);
          } else if (action.type === 'coins') {
            if (ach.id === 'coins_100') progress = Math.max(progress, action.value || 0);
            if (ach.id === 'coins_500') progress = Math.max(progress, action.value || 0);
          } else if (action.type === 'combo') {
            if (ach.id === 'combo_5') progress = Math.max(progress, action.value || 0);
            if (ach.id === 'combo_10') progress = Math.max(progress, action.value || 0);
          } else if (action.type === 'double_jump' && ach.id === 'double_jump_20') {
            progress = Math.min(ach.maxProgress, progress + 1);
          } else if (action.type === 'beat_level') {
            if (action.levelId === 1 && ach.id === 'beat_level_1') progress = 1;
            if (action.levelId === 5 && ach.id === 'beat_level_5') progress = 1;
          }

          if (progress !== ach.progress) {
            modified = true;
            return { ...ach, progress };
          }
          return ach;
        });

        if (modified) {
          saveAchievements(next);
        }
        return next;
      });
    },
    []
  );

  // Claim achievement reward
  const handleClaimReward = (id: string, coins: number) => {
    setAchievements((prev) => {
      const next = prev.map((a) => (a.id === id ? { ...a, unlocked: true } : a));
      saveAchievements(next);
      return next;
    });

    updateStats((prev) => ({
      ...prev,
      totalCoins: prev.totalCoins + coins,
    }));
  };

  // Start Playing
  const startRun = (mode: GameMode, levelId: number = 1) => {
    setGameMode(mode);
    setCurrentLevelId(levelId);
    setCurrentScore(0);
    setCurrentCoins(0);
    setCurrentDistance(0);
    setCurrentCombo(1);
    setPowerUps({ magnet: 0, energyBoost: 0, shield: false, doubleCoins: 0 });
    setIsPaused(false);
    setGameState('PLAYING');

    checkAchievements({ type: 'run_started' });

    if (stats.musicEnabled) {
      audio.startMusic();
    }
  };

  // Handlers for in-game updates
  const handleScoreChange = useCallback((score: number) => {
    setCurrentScore(score);
  }, []);

  const handleCoinsChange = useCallback(
    (coins: number) => {
      setCurrentCoins(coins);
      checkAchievements({ type: 'coins', value: stats.totalCoins + coins });
    },
    [checkAchievements, stats.totalCoins]
  );

  const handleDistanceChange = useCallback(
    (distance: number) => {
      setCurrentDistance(distance);
      checkAchievements({ type: 'distance', value: distance });
    },
    [checkAchievements]
  );

  const handleComboChange = useCallback(
    (combo: number) => {
      setCurrentCombo(combo);
      checkAchievements({ type: 'combo', value: combo });
    },
    [checkAchievements]
  );

  const handlePowerUpsChange = useCallback((newPowerUps: PowerUpState) => {
    setPowerUps({ ...newPowerUps });
  }, []);

  // Handle Game Over
  const handleGameOver = useCallback(
    (result: { score: number; distance: number; coins: number; comboPeak: number }) => {
      audio.stopMusic();

      const isNewHighScore = result.score > stats.highestScore;
      const newHighestScore = Math.max(stats.highestScore, result.score);
      const newTotalCoins = stats.totalCoins + result.coins;
      const newTotalDistance = stats.totalDistance + result.distance;
      const newHighestCombo = Math.max(stats.highestCombo, result.comboPeak);

      updateStats((prev) => ({
        ...prev,
        totalRuns: prev.totalRuns + 1,
        totalCoins: newTotalCoins,
        totalDistance: newTotalDistance,
        highestScore: newHighestScore,
        highestCombo: newHighestCombo,
      }));

      // Update leaderboard
      const updatedLeaderboard = loadLeaderboard(
        newHighestScore,
        result.distance,
        result.coins,
        currentSkin.name
      );
      setLeaderboard(updatedLeaderboard);

      setLastRunStats({
        score: result.score,
        distance: result.distance,
        coins: result.coins,
        comboPeak: result.comboPeak,
        isNewHighScore,
      });

      setGameState('GAME_OVER');
    },
    [currentSkin.name, stats.highestCombo, stats.highestScore, stats.totalCoins, stats.totalDistance, updateStats]
  );

  // Handle Level Victory
  const handleVictory = useCallback(
    (result: { score: number; distance: number; coins: number; stars: number }) => {
      audio.stopMusic();

      const completionBonus = 100;
      const totalEarnedCoins = result.coins + completionBonus;
      const newTotalCoins = stats.totalCoins + totalEarnedCoins;
      const newHighestScore = Math.max(stats.highestScore, result.score);

      updateStats((prev) => ({
        ...prev,
        totalCoins: newTotalCoins,
        highestScore: newHighestScore,
        totalDistance: prev.totalDistance + result.distance,
      }));

      // Check level achievements
      checkAchievements({ type: 'beat_level', levelId: currentLevelId });

      // Unlock next level
      setLevels((prevLevels) => {
        const next = prevLevels.map((lvl) => {
          if (lvl.id === currentLevelId) {
            return {
              ...lvl,
              stars: Math.max(lvl.stars, result.stars),
              highScore: Math.max(lvl.highScore, result.score),
            };
          }
          if (lvl.id === currentLevelId + 1) {
            return {
              ...lvl,
              unlocked: true,
            };
          }
          return lvl;
        });
        saveLevels(next);
        return next;
      });

      setLastVictoryStats({
        score: result.score,
        distance: result.distance,
        coins: totalEarnedCoins,
        stars: result.stars,
      });

      setGameState('VICTORY');
    },
    [currentLevelId, stats.highestScore, stats.totalCoins, updateStats, checkAchievements]
  );

  // Skin purchase and selection
  const handleSelectSkin = (skinId: string) => {
    updateStats((prev) => ({ ...prev, selectedSkin: skinId }));
  };

  const handleUnlockSkin = (skinId: string, price: number) => {
    if (stats.totalCoins >= price) {
      updateStats((prev) => ({
        ...prev,
        totalCoins: prev.totalCoins - price,
        unlockedSkins: [...prev.unlockedSkins, skinId],
        selectedSkin: skinId,
      }));

      setAllSkins((prev) =>
        prev.map((s) => (s.id === skinId ? { ...s, unlocked: true } : s))
      );
    }
  };

  // Audio Toggles
  const toggleSound = () => {
    updateStats((prev) => ({ ...prev, soundEnabled: !prev.soundEnabled }));
  };

  const toggleMusic = () => {
    updateStats((prev) => ({ ...prev, musicEnabled: !prev.musicEnabled }));
  };

  return (
    <div className="flex flex-col h-screen w-full bg-slate-950 text-slate-100 overflow-hidden font-sans">
      {/* Top Bar Contract (Strict 3-zone layout) */}
      <header className="flex items-center justify-between gap-8 px-4 sm:px-6 py-3 border-b border-slate-800 bg-slate-950/90 backdrop-blur-md shrink-0 z-30">
        {/* Zone 1: Single text element wordmark */}
        <button
          type="button"
          onClick={() => {
            if (gameState === 'PLAYING') audio.stopMusic();
            setGameState('TITLE_MENU');
          }}
          className="text-base sm:text-lg font-black tracking-tight text-white whitespace-nowrap shrink-0 flex items-center gap-2 hover:text-amber-400 transition-colors cursor-pointer font-display"
        >
          <span className="text-xl">🐹</span>
          <span>Hamster Wheel Adventure</span>
        </button>

        {/* Zone 2: 4-5 clean single-line navigation links */}
        <nav className="hidden md:flex items-center gap-6 text-xs font-semibold text-slate-300">
          <button
            type="button"
            onClick={() => setGameState('LEVEL_SELECT')}
            className="hover:text-amber-400 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Adventure Levels
          </button>
          <button
            type="button"
            onClick={() => startRun('ENDLESS')}
            className="hover:text-amber-400 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Endless Runner
          </button>
          <button
            type="button"
            onClick={() => setGameState('LOCKER')}
            className="hover:text-amber-400 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Squeek Locker
          </button>
          <button
            type="button"
            onClick={() => setGameState('LEADERBOARD')}
            className="hover:text-amber-400 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Leaderboard
          </button>
          <button
            type="button"
            onClick={() => setGameState('ACHIEVEMENTS')}
            className="hover:text-amber-400 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Achievements
          </button>
        </nav>

        {/* Zone 3: 1 primary action */}
        <div className="flex items-center gap-3 shrink-0">
          {gameState === 'PLAYING' ? (
            <button
              type="button"
              onClick={() => setIsPaused(true)}
              className="px-3.5 py-1.5 text-xs font-bold text-slate-200 bg-slate-900 border border-slate-700 rounded-lg hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Pause Run
            </button>
          ) : (
            <button
              type="button"
              onClick={() => startRun('LEVELS', 1)}
              className="flex items-center gap-1.5 px-4 py-1.5 text-xs font-black text-slate-950 bg-amber-500 rounded-lg hover:bg-amber-400 transition-colors whitespace-nowrap shrink-0 cursor-pointer shadow-md shadow-amber-500/20 active:scale-95"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>Spin Now</span>
            </button>
          )}
        </div>
      </header>

      {/* Main Game Screen Viewport */}
      <main className="relative flex-1 w-full h-full overflow-hidden bg-slate-950">
        {gameState === 'TITLE_MENU' && (
          <TitleScreen
            stats={stats}
            currentSkin={currentSkin}
            onPlayAdventure={() => setGameState('LEVEL_SELECT')}
            onPlayEndless={() => startRun('ENDLESS')}
            onOpenLocker={() => setGameState('LOCKER')}
            onOpenLeaderboard={() => setGameState('LEADERBOARD')}
            onOpenAchievements={() => setGameState('ACHIEVEMENTS')}
            onToggleSound={toggleSound}
            onToggleMusic={toggleMusic}
          />
        )}

        {gameState === 'PLAYING' && (
          <div className="relative w-full h-full">
            <GameHUD
              score={currentScore}
              coins={currentCoins}
              distance={currentDistance}
              combo={currentCombo}
              powerUps={powerUps}
              level={currentLevel}
              mode={gameMode}
              onPause={() => setIsPaused(true)}
            />
            <GameCanvas
              level={currentLevel}
              skin={currentSkin}
              mode={gameMode}
              isPaused={isPaused}
              onScoreChange={handleScoreChange}
              onCoinsChange={handleCoinsChange}
              onDistanceChange={handleDistanceChange}
              onComboChange={handleComboChange}
              onPowerUpsChange={handlePowerUpsChange}
              onGameOver={handleGameOver}
              onVictory={handleVictory}
            />
          </div>
        )}

        {/* Modals and Overlays */}
        {isPaused && (
          <PauseModal
            soundEnabled={stats.soundEnabled}
            musicEnabled={stats.musicEnabled}
            onResume={() => setIsPaused(false)}
            onRestart={() => {
              setIsPaused(false);
              startRun(gameMode, currentLevelId);
            }}
            onToggleSound={toggleSound}
            onToggleMusic={toggleMusic}
            onMainMenu={() => {
              setIsPaused(false);
              audio.stopMusic();
              setGameState('TITLE_MENU');
            }}
          />
        )}

        {gameState === 'LEVEL_SELECT' && (
          <LevelSelectModal
            levels={levels}
            onSelectLevel={(id) => startRun('LEVELS', id)}
            onClose={() => setGameState('TITLE_MENU')}
          />
        )}

        {gameState === 'LOCKER' && (
          <LockerModal
            allSkins={allSkins}
            selectedSkinId={stats.selectedSkin}
            totalCoins={stats.totalCoins}
            onSelectSkin={handleSelectSkin}
            onUnlockSkin={handleUnlockSkin}
            onClose={() => setGameState('TITLE_MENU')}
          />
        )}

        {gameState === 'LEADERBOARD' && (
          <LeaderboardModal
            entries={leaderboard}
            playerScore={stats.highestScore}
            onClose={() => setGameState('TITLE_MENU')}
          />
        )}

        {gameState === 'ACHIEVEMENTS' && (
          <AchievementsModal
            achievements={achievements}
            onClaimReward={handleClaimReward}
            onClose={() => setGameState('TITLE_MENU')}
          />
        )}

        {gameState === 'GAME_OVER' && (
          <GameOverModal
            score={lastRunStats.score}
            distance={lastRunStats.distance}
            coins={lastRunStats.coins}
            comboPeak={lastRunStats.comboPeak}
            isNewHighScore={lastRunStats.isNewHighScore}
            onRestart={() => startRun(gameMode, currentLevelId)}
            onOpenLocker={() => setGameState('LOCKER')}
            onMainMenu={() => setGameState('TITLE_MENU')}
          />
        )}

        {gameState === 'VICTORY' && (
          <VictoryModal
            level={currentLevel}
            score={lastVictoryStats.score}
            distance={lastVictoryStats.distance}
            coins={lastVictoryStats.coins}
            stars={lastVictoryStats.stars}
            hasNextLevel={currentLevelId < levels.length}
            onNextLevel={() => startRun('LEVELS', currentLevelId + 1)}
            onReplay={() => startRun('LEVELS', currentLevelId)}
            onMainMenu={() => setGameState('TITLE_MENU')}
          />
        )}
      </main>
    </div>
  );
}
