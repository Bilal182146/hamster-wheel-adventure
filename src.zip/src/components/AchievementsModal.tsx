import { Achievement } from '../types/game';
import { Award, Check, Coins, X } from 'lucide-react';
import { audio } from '../utils/audio';

interface AchievementsModalProps {
  achievements: Achievement[];
  onClaimReward: (id: string, coins: number) => void;
  onClose: () => void;
}

export function AchievementsModal({
  achievements,
  onClaimReward,
  onClose,
}: AchievementsModalProps) {
  const completedCount = achievements.filter((a) => a.unlocked).length;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div className="bg-slate-900 border border-slate-700/80 rounded-2xl max-w-xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <Award className="w-5 h-5 text-amber-400" />
            <div>
              <h2 className="text-xl font-black text-white font-display">COMMUNITY ACHIEVEMENTS</h2>
              <p className="text-xs text-slate-400">
                Completed {completedCount} of {achievements.length} challenges
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-lg bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Achievement List */}
        <div className="p-6 space-y-3 overflow-y-auto">
          {achievements.map((ach) => {
            const isCompleted = ach.progress >= ach.maxProgress;
            const isClaimed = ach.unlocked;
            const percent = Math.min(100, Math.floor((ach.progress / ach.maxProgress) * 100));

            return (
              <div
                key={ach.id}
                className={`p-3.5 rounded-xl border flex items-center justify-between gap-4 transition-all ${
                  isClaimed
                    ? 'bg-slate-800/40 border-slate-800'
                    : isCompleted
                    ? 'bg-amber-500/10 border-amber-500/50 shadow-md'
                    : 'bg-slate-800/70 border-slate-700/60'
                }`}
              >
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-white text-sm">{ach.title}</span>
                    <span className="flex items-center gap-1 text-[11px] font-bold text-amber-400 bg-amber-500/15 px-1.5 py-0.5 rounded">
                      <Coins className="w-3 h-3" />
                      +{ach.rewardCoins} $SQUEEK
                    </span>
                  </div>
                  <div className="text-xs text-slate-400 mt-0.5">{ach.description}</div>

                  {/* Progress Bar */}
                  <div className="mt-2 flex items-center gap-2">
                    <div className="flex-1 h-1.5 bg-slate-800 rounded-full overflow-hidden border border-slate-700/50">
                      <div
                        className="h-full bg-amber-400 rounded-full transition-all duration-300"
                        style={{ width: `${percent}%` }}
                      />
                    </div>
                    <span className="text-[10px] text-slate-500 font-mono tabular-nums">
                      {ach.progress}/{ach.maxProgress}
                    </span>
                  </div>
                </div>

                {/* Claim or Status Button */}
                <div className="shrink-0">
                  {isClaimed ? (
                    <div className="flex items-center gap-1 text-emerald-400 text-xs font-bold px-2 py-1 bg-emerald-500/15 rounded-lg">
                      <Check className="w-3.5 h-3.5" />
                      <span>Claimed</span>
                    </div>
                  ) : isCompleted ? (
                    <button
                      type="button"
                      onClick={() => {
                        onClaimReward(ach.id, ach.rewardCoins);
                        audio.playVictory();
                      }}
                      className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs uppercase tracking-wider transition-all active:scale-95 shadow-md shadow-amber-500/20 cursor-pointer"
                    >
                      Claim
                    </button>
                  ) : (
                    <div className="text-xs text-slate-500 font-semibold px-2 py-1">
                      In Progress
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
