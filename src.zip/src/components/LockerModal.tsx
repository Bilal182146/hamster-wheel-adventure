import { useEffect, useRef, useState } from 'react';
import { HamsterSkin } from '../types/game';
import { HamsterRenderer, HamsterAnimState } from '../game/HamsterRenderer';
import { audio } from '../utils/audio';
import { Check, Coins, Lock, Sparkles, X } from 'lucide-react';

interface LockerModalProps {
  allSkins: HamsterSkin[];
  selectedSkinId: string;
  totalCoins: number;
  onSelectSkin: (skinId: string) => void;
  onUnlockSkin: (skinId: string, price: number) => void;
  onClose: () => void;
}

export function LockerModal({
  allSkins,
  selectedSkinId,
  totalCoins,
  onSelectSkin,
  onUnlockSkin,
  onClose,
}: LockerModalProps) {
  const [previewSkinId, setPreviewSkinId] = useState<string>(selectedSkinId);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const currentPreviewSkin = allSkins.find((s) => s.id === previewSkinId) || allSkins[0];
  const isUnlocked = currentPreviewSkin.unlocked;
  const isEquipped = currentPreviewSkin.id === selectedSkinId;
  const canAfford = totalCoins >= currentPreviewSkin.price;

  // Mini live canvas preview animation
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let runCycle = 0;

    const hamsterState: HamsterAnimState = {
      x: 65,
      y: 60,
      width: 44,
      height: 44,
      vy: 0,
      isGrounded: true,
      isRolling: false,
      isDoubleJumping: false,
      spinAngle: 0,
      runCycle: 0,
      invincibleTimer: 0,
    };

    const emptyPowerUps = {
      magnet: 0,
      energyBoost: 0,
      shield: false,
      doubleCoins: 0,
    };

    const render = () => {
      runCycle += 0.08;
      hamsterState.runCycle = runCycle;

      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Warm radial pedestal
      const grad = ctx.createRadialGradient(88, 88, 10, 88, 88, 75);
      grad.addColorStop(0, 'rgba(245, 158, 11, 0.25)');
      grad.addColorStop(1, 'rgba(15, 23, 42, 0)');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Rotating mini golden wheel ring
      ctx.save();
      ctx.translate(88, 88);
      ctx.rotate(runCycle * 0.3);
      ctx.beginPath();
      ctx.arc(0, 0, 70, 0, Math.PI * 2);
      ctx.strokeStyle = 'rgba(245, 158, 11, 0.4)';
      ctx.lineWidth = 6;
      ctx.stroke();
      ctx.restore();

      // Draw hamster
      HamsterRenderer.drawHamster(ctx, hamsterState, currentPreviewSkin, emptyPowerUps);

      animId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animId);
    };
  }, [currentPreviewSkin]);

  const handleUnlock = () => {
    if (canAfford) {
      onUnlockSkin(currentPreviewSkin.id, currentPreviewSkin.price);
      audio.playVictory();
    } else {
      audio.playHit();
    }
  };

  const handleEquip = () => {
    onSelectSkin(currentPreviewSkin.id);
    audio.playBounce();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div className="bg-slate-900 border border-slate-700/80 rounded-2xl max-w-2xl w-full max-h-[92vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <Sparkles className="w-5 h-5 text-amber-400" />
            <div>
              <h2 className="text-xl font-black text-white font-display">SQUEEK LOCKER</h2>
              <p className="text-xs text-slate-400">Unlock & equip exclusive community skins</p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 border border-amber-500/30 text-amber-300 font-bold text-xs sm:text-sm">
              <Coins className="w-4 h-4 text-amber-400" />
              <span className="tabular-nums">{totalCoins}</span>
              <span className="text-[10px] text-amber-500 font-bold hidden sm:inline">$SQUEEK</span>
            </div>

            <button
              type="button"
              onClick={onClose}
              className="w-8 h-8 rounded-lg bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Content Body: Split Preview & List */}
        <div className="p-6 grid grid-cols-1 md:grid-cols-5 gap-6 overflow-y-auto">
          {/* Left Column: Interactive 3D/2D Character Showcase */}
          <div className="md:col-span-2 flex flex-col items-center justify-between p-4 rounded-xl bg-slate-950/60 border border-slate-800">
            <div className="text-center">
              <div className="text-xs uppercase tracking-wider text-amber-400 font-bold">Skin Showcase</div>
              <h3 className="text-lg font-black text-white mt-0.5">{currentPreviewSkin.name}</h3>
            </div>

            {/* Live Animated Canvas */}
            <div className="my-4 relative">
              <canvas
                ref={canvasRef}
                width={176}
                height={176}
                className="w-44 h-44 rounded-full bg-slate-900 border-2 border-amber-500/40 shadow-inner"
              />
            </div>

            <p className="text-xs text-slate-400 text-center px-2 line-clamp-3 mb-4">
              {currentPreviewSkin.description}
            </p>

            {/* Action Button */}
            <div className="w-full">
              {isEquipped ? (
                <div className="w-full py-2.5 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 font-bold text-xs text-center flex items-center justify-center gap-1.5">
                  <Check className="w-4 h-4" />
                  <span>Currently Equipped</span>
                </div>
              ) : isUnlocked ? (
                <button
                  type="button"
                  onClick={handleEquip}
                  className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs uppercase tracking-wider transition-all active:scale-95 shadow-md shadow-amber-500/20"
                >
                  Equip Runner
                </button>
              ) : (
                <button
                  type="button"
                  disabled={!canAfford}
                  onClick={handleUnlock}
                  className={`w-full py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-all active:scale-95 shadow-md ${
                    canAfford
                      ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 hover:from-amber-400 hover:to-amber-500 cursor-pointer shadow-amber-500/25'
                      : 'bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed'
                  }`}
                >
                  <Lock className="w-3.5 h-3.5" />
                  <span>Unlock ({currentPreviewSkin.price} $SQUEEK)</span>
                </button>
              )}
            </div>
          </div>

          {/* Right Column: Skin Selection Grid */}
          <div className="md:col-span-3 space-y-2.5">
            {allSkins.map((skin) => {
              const isSelected = skin.id === previewSkinId;
              const isEquippedSkin = skin.id === selectedSkinId;
              const unlocked = skin.unlocked;

              return (
                <div
                  key={skin.id}
                  onClick={() => setPreviewSkinId(skin.id)}
                  className={`flex items-center justify-between p-3 rounded-xl border cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-slate-800 border-amber-500 shadow-md shadow-amber-500/10'
                      : 'bg-slate-800/40 border-slate-800 hover:border-slate-700 hover:bg-slate-800/60'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    {/* Fur color swatch avatar */}
                    <div
                      className="w-10 h-10 rounded-full flex items-center justify-center shadow-inner relative border border-white/20"
                      style={{ backgroundColor: skin.primaryColor }}
                    >
                      <div
                        className="w-5 h-5 rounded-full"
                        style={{ backgroundColor: skin.bellyColor }}
                      />
                      {!unlocked && (
                        <div className="absolute inset-0 bg-slate-950/70 rounded-full flex items-center justify-center text-slate-400">
                          <Lock className="w-3.5 h-3.5" />
                        </div>
                      )}
                    </div>

                    <div>
                      <div className="font-bold text-white text-sm flex items-center gap-1.5">
                        <span>{skin.name}</span>
                        {isEquippedSkin && (
                          <span className="text-[10px] font-bold text-emerald-400 bg-emerald-500/15 px-1.5 py-0.5 rounded">
                            EQUIPPED
                          </span>
                        )}
                      </div>
                      <div className="text-xs text-slate-400">
                        {unlocked ? (
                          <span className="text-emerald-400 font-medium">Ready</span>
                        ) : (
                          <span className="text-amber-400 font-bold">{skin.price} $SQUEEK</span>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="text-xs text-slate-400 font-semibold">
                    {isSelected ? 'Viewing' : 'Select'}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
