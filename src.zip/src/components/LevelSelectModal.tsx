import { LevelConfig } from '../types/game';
import { Star, Lock, Play, X } from 'lucide-react';

interface LevelSelectModalProps {
  levels: LevelConfig[];
  onSelectLevel: (levelId: number) => void;
  onClose: () => void;
}

export function LevelSelectModal({
  levels,
  onSelectLevel,
  onClose,
}: LevelSelectModalProps) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div className="bg-slate-900 border border-slate-700/80 rounded-2xl max-w-xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div>
            <h2 className="text-xl font-black text-white font-display">SELECT ADVENTURE LEVEL</h2>
            <p className="text-xs text-slate-400">Complete each stage to unlock the next environment</p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-lg bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Level List */}
        <div className="p-6 space-y-3 overflow-y-auto">
          {levels.map((lvl) => {
            const isUnlocked = lvl.unlocked;

            return (
              <div
                key={lvl.id}
                className={`flex items-center justify-between p-4 rounded-xl border transition-all ${
                  isUnlocked
                    ? 'bg-slate-800/80 border-slate-700 hover:border-amber-500/50 hover:bg-slate-800'
                    : 'bg-slate-900/40 border-slate-800/60 opacity-60'
                }`}
              >
                <div className="flex items-center gap-3.5">
                  {/* Level Number Badge */}
                  <div
                    className="w-12 h-12 rounded-xl flex items-center justify-center font-black text-lg font-display shrink-0"
                    style={{
                      backgroundColor: isUnlocked ? lvl.wheelAccentColor : '#334155',
                      color: isUnlocked ? '#0f172a' : '#64748b',
                    }}
                  >
                    {isUnlocked ? lvl.id : <Lock className="w-5 h-5 text-slate-400" />}
                  </div>

                  <div>
                    <div className="font-bold text-white text-base flex items-center gap-2">
                      <span>{lvl.name}</span>
                    </div>
                    <div className="text-xs text-slate-400 mt-0.5">{lvl.subtitle}</div>

                    {/* Stars and Target */}
                    <div className="flex items-center gap-3 mt-1.5 text-xs">
                      <span className="text-amber-400 font-semibold">Goal: {lvl.targetDistance}m</span>
                      <span aria-hidden="true" className="text-slate-600">·</span>
                      <div className="flex items-center gap-0.5">
                        {[1, 2, 3].map((starIdx) => (
                          <Star
                            key={starIdx}
                            className={`w-3.5 h-3.5 ${
                              starIdx <= lvl.stars
                                ? 'text-amber-400 fill-amber-400'
                                : 'text-slate-600'
                            }`}
                          />
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Action */}
                <div>
                  {isUnlocked ? (
                    <button
                      type="button"
                      onClick={() => onSelectLevel(lvl.id)}
                      className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs uppercase tracking-wider transition-all active:scale-95 cursor-pointer shadow-md shadow-amber-500/20"
                    >
                      <Play className="w-3.5 h-3.5 fill-current" />
                      <span>Play</span>
                    </button>
                  ) : (
                    <div className="px-3 py-1.5 rounded-lg bg-slate-800/80 text-slate-500 text-xs font-semibold flex items-center gap-1">
                      <Lock className="w-3 h-3" />
                      <span>Locked</span>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
