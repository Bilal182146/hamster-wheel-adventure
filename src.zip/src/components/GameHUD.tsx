import { Pause, Flame, Shield, Zap, Magnet, Coins } from 'lucide-react';
import { PowerUpState, LevelConfig, GameMode } from '../types/game';

interface GameHUDProps {
  score: number;
  coins: number;
  distance: number;
  combo: number;
  powerUps: PowerUpState;
  level: LevelConfig;
  mode: GameMode;
  onPause: () => void;
}

export function GameHUD({
  score,
  coins,
  distance,
  combo,
  powerUps,
  level,
  mode,
  onPause,
}: GameHUDProps) {
  const targetDistance = level.targetDistance;
  const progressPercent = mode === 'LEVELS'
    ? Math.min(100, (distance / targetDistance) * 100)
    : 100;

  return (
    <div className="absolute top-0 inset-x-0 p-3 sm:p-4 pointer-events-none z-20 flex flex-col gap-2">
      {/* Top Main Bar */}
      <div className="flex items-center justify-between gap-3">
        {/* Left: Score & SQUEEK Coins */}
        <div className="flex items-center gap-2 sm:gap-3 pointer-events-auto">
          {/* Score */}
          <div className="bg-slate-900/85 backdrop-blur-md border border-slate-700/60 rounded-xl px-3 py-1.5 shadow-md flex items-center gap-2">
            <span className="text-slate-400 text-xs font-semibold uppercase tracking-wider">Score</span>
            <span className="text-amber-300 font-extrabold text-base sm:text-lg tabular-nums tracking-wide font-display">
              {score.toLocaleString()}
            </span>
          </div>

          {/* SQUEEK Coins */}
          <div className="bg-slate-900/85 backdrop-blur-md border border-amber-500/30 rounded-xl px-3 py-1.5 shadow-md flex items-center gap-1.5 text-amber-400">
            <Coins className="w-4 h-4 text-amber-400" />
            <span className="text-amber-300 font-bold text-sm sm:text-base tabular-nums">
              {coins}
            </span>
            <span className="text-[10px] text-amber-500 font-bold hidden sm:inline">$SQUEEK</span>
          </div>
        </div>

        {/* Center: Distance & Level Goal Progress */}
        <div className="hidden md:flex flex-col items-center max-w-[220px] w-full">
          <div className="flex items-center justify-between w-full text-xs font-bold text-slate-300 mb-1">
            <span>{level.name}</span>
            <span className="tabular-nums text-amber-400">{distance}m {mode === 'LEVELS' && `/ ${targetDistance}m`}</span>
          </div>
          {mode === 'LEVELS' && (
            <div className="w-full h-2 bg-slate-800/80 rounded-full overflow-hidden border border-slate-700/50">
              <div
                className="h-full bg-gradient-to-r from-amber-500 to-amber-300 rounded-full transition-all duration-200"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
          )}
        </div>

        {/* Right: Combo & Pause Button */}
        <div className="flex items-center gap-2 pointer-events-auto">
          {/* Combo Multiplier */}
          {combo > 1 && (
            <div className="flex items-center gap-1 bg-gradient-to-r from-amber-600 to-rose-600 text-white font-black px-2.5 py-1 rounded-xl shadow-lg animate-pulse text-xs sm:text-sm">
              <Flame className="w-3.5 h-3.5 fill-current" />
              <span>{combo}X COMBO</span>
            </div>
          )}

          {/* Distance (Mobile view) */}
          <div className="md:hidden bg-slate-900/85 backdrop-blur-md border border-slate-700/60 rounded-xl px-2.5 py-1.5 text-xs text-slate-300 font-bold tabular-nums">
            {distance}m
          </div>

          {/* Pause Button */}
          <button
            type="button"
            onClick={onPause}
            aria-label="Pause Game"
            className="w-9 h-9 rounded-xl bg-slate-900/85 backdrop-blur-md border border-slate-700/60 flex items-center justify-center text-slate-300 hover:text-white hover:bg-slate-800 transition-all active:scale-95 shadow-md"
          >
            <Pause className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Active Power-Ups Row */}
      <div className="flex items-center gap-2 self-start pointer-events-none">
        {powerUps.magnet > 0 && (
          <div className="flex items-center gap-1.5 bg-amber-500/20 backdrop-blur-md border border-amber-400/40 text-amber-300 text-xs font-bold px-2 py-1 rounded-lg">
            <Magnet className="w-3.5 h-3.5 text-amber-400 animate-spin" />
            <span>Magnet {powerUps.magnet.toFixed(1)}s</span>
          </div>
        )}

        {powerUps.energyBoost > 0 && (
          <div className="flex items-center gap-1.5 bg-rose-500/20 backdrop-blur-md border border-rose-400/40 text-rose-300 text-xs font-bold px-2 py-1 rounded-lg">
            <Zap className="w-3.5 h-3.5 text-rose-400" />
            <span>Turbo {powerUps.energyBoost.toFixed(1)}s</span>
          </div>
        )}

        {powerUps.shield && (
          <div className="flex items-center gap-1.5 bg-sky-500/20 backdrop-blur-md border border-sky-400/40 text-sky-300 text-xs font-bold px-2 py-1 rounded-lg">
            <Shield className="w-3.5 h-3.5 text-sky-400" />
            <span>Shield Active</span>
          </div>
        )}

        {powerUps.doubleCoins > 0 && (
          <div className="flex items-center gap-1.5 bg-emerald-500/20 backdrop-blur-md border border-emerald-400/40 text-emerald-300 text-xs font-bold px-2 py-1 rounded-lg">
            <span className="text-emerald-400 font-extrabold text-xs">2X</span>
            <span>Coins {powerUps.doubleCoins.toFixed(1)}s</span>
          </div>
        )}
      </div>
    </div>
  );
}
