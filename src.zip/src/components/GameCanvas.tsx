import { useEffect, useRef, useState, useCallback } from 'react';
import { GameEngine } from '../game/GameEngine';
import { LevelConfig, HamsterSkin, GameMode, PowerUpState } from '../types/game';
import { ArrowUp, ArrowDown } from 'lucide-react';

interface GameCanvasProps {
  level: LevelConfig;
  skin: HamsterSkin;
  mode: GameMode;
  onScoreChange: (score: number) => void;
  onCoinsChange: (coins: number) => void;
  onDistanceChange: (distance: number) => void;
  onComboChange: (combo: number) => void;
  onPowerUpsChange: (powerUps: PowerUpState) => void;
  onGameOver: (stats: { score: number; distance: number; coins: number; comboPeak: number }) => void;
  onVictory: (stats: { score: number; distance: number; coins: number; stars: number }) => void;
  isPaused: boolean;
}

export function GameCanvas({
  level,
  skin,
  mode,
  onScoreChange,
  onCoinsChange,
  onDistanceChange,
  onComboChange,
  onPowerUpsChange,
  onGameOver,
  onVictory,
  isPaused,
}: GameCanvasProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<GameEngine | null>(null);

  // Touch tracking for swipe down to roll
  const touchStartY = useRef<number>(0);
  const [touchFeedback, setTouchFeedback] = useState<'jump' | 'roll' | null>(null);

  const handleJump = useCallback(() => {
    if (engineRef.current && !isPaused) {
      engineRef.current.handleJump();
      setTouchFeedback('jump');
      setTimeout(() => setTouchFeedback(null), 150);
      if (typeof navigator !== 'undefined' && navigator.vibrate) {
        try { navigator.vibrate(15); } catch { /* ignore */ }
      }
    }
  }, [isPaused]);

  const handleRoll = useCallback(() => {
    if (engineRef.current && !isPaused) {
      engineRef.current.handleRoll();
      setTouchFeedback('roll');
      setTimeout(() => setTouchFeedback(null), 150);
      if (typeof navigator !== 'undefined' && navigator.vibrate) {
        try { navigator.vibrate(25); } catch { /* ignore */ }
      }
    }
  }, [isPaused]);

  // Initialize and resize game engine
  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    const width = container.clientWidth || 800;
    const height = container.clientHeight || 450;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);

    canvas.width = width * dpr;
    canvas.height = height * dpr;
    canvas.style.width = `${width}px`;
    canvas.style.height = `${height}px`;

    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.scale(dpr, dpr);
    }

    const engine = new GameEngine(canvas, level, skin, mode, {
      onScoreChange,
      onCoinsChange,
      onDistanceChange,
      onComboChange,
      onPowerUpsChange,
      onGameOver,
      onVictory,
    });

    engine.setSize(width, height);
    engine.start();
    engineRef.current = engine;

    const handleResize = () => {
      if (!container || !canvas || !engineRef.current) return;
      const newWidth = container.clientWidth;
      const newHeight = container.clientHeight;
      const newDpr = Math.min(window.devicePixelRatio || 1, 2);

      canvas.width = newWidth * newDpr;
      canvas.height = newHeight * newDpr;
      canvas.style.width = `${newWidth}px`;
      canvas.style.height = `${newHeight}px`;

      const c = canvas.getContext('2d');
      if (c) {
        c.scale(newDpr, newDpr);
      }
      engineRef.current.setSize(newWidth, newHeight);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      engine.stop();
      engineRef.current = null;
    };
  }, [level, skin, mode, onCoinsChange, onComboChange, onDistanceChange, onGameOver, onPowerUpsChange, onScoreChange, onVictory]);

  // Pause / Resume sync
  useEffect(() => {
    if (!engineRef.current) return;
    if (isPaused) {
      engineRef.current.pause();
    } else {
      engineRef.current.resume();
    }
  }, [isPaused]);

  // Keyboard controls
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.repeat) return;
      if (e.code === 'Space' || e.code === 'ArrowUp' || e.code === 'KeyW') {
        e.preventDefault();
        handleJump();
      } else if (e.code === 'ArrowDown' || e.code === 'KeyS') {
        e.preventDefault();
        handleRoll();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleJump, handleRoll]);

  // Touch screen gestures
  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartY.current = e.touches[0].clientY;
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    const touchEndY = e.changedTouches[0].clientY;
    const deltaY = touchEndY - touchStartY.current;

    // Swipe down triggers roll
    if (deltaY > 35) {
      handleRoll();
    } else {
      // Tap triggers jump
      handleJump();
    }
  };

  return (
    <div
      ref={containerRef}
      className="relative w-full h-full select-none touch-none overflow-hidden bg-slate-950"
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
      onClick={handleJump}
    >
      <canvas ref={canvasRef} className="block w-full h-full cursor-pointer" />

      {/* Touch visual ripple feedback */}
      {touchFeedback && (
        <div className="absolute inset-0 pointer-events-none bg-white/5 transition-opacity duration-150" />
      )}

      {/* Mobile-Friendly Ergonomic Virtual Controls (Bottom Strip) */}
      <div
        className="absolute bottom-3 inset-x-3 flex items-center justify-between pointer-events-none z-10"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Left: DUCK / ROLL BUTTON */}
        <button
          type="button"
          aria-label="Roll and Duck"
          className="pointer-events-auto flex items-center gap-2 px-5 py-3 rounded-2xl bg-slate-900/85 backdrop-blur-md border border-slate-700/60 text-slate-100 font-bold active:scale-95 active:bg-amber-600 transition-all shadow-lg active:shadow-amber-500/20"
          onTouchStart={(e) => {
            e.stopPropagation();
            handleRoll();
          }}
          onClick={(e) => {
            e.stopPropagation();
            handleRoll();
          }}
        >
          <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center text-amber-400">
            <ArrowDown className="w-5 h-5" />
          </div>
          <div className="text-left">
            <div className="text-xs uppercase tracking-wider text-slate-400 font-medium">Under</div>
            <div className="text-sm font-bold text-amber-300">ROLL</div>
          </div>
        </button>

        {/* Right: JUMP BUTTON */}
        <button
          type="button"
          aria-label="Jump and Double Jump"
          className="pointer-events-auto flex items-center gap-2 px-6 py-3.5 rounded-2xl bg-amber-500/90 backdrop-blur-md border border-amber-400 text-slate-950 font-extrabold active:scale-95 active:bg-amber-400 transition-all shadow-xl shadow-amber-500/30"
          onTouchStart={(e) => {
            e.stopPropagation();
            handleJump();
          }}
          onClick={(e) => {
            e.stopPropagation();
            handleJump();
          }}
        >
          <div className="w-9 h-9 rounded-full bg-slate-950 flex items-center justify-center text-amber-400">
            <ArrowUp className="w-6 h-6 stroke-[3]" />
          </div>
          <div className="text-left">
            <div className="text-xs uppercase tracking-wider text-slate-900 font-semibold">Tap to</div>
            <div className="text-base font-black">JUMP</div>
          </div>
        </button>
      </div>
    </div>
  );
}
