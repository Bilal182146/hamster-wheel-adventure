import { Star, Trophy, ArrowRight, RotateCcw, Home, Coins } from 'lucide-react';
import { LevelConfig } from '../types/game';

interface VictoryModalProps {
  level: LevelConfig;
  score: number;
  distance: number;
  coins: number;
  stars: number;
  hasNextLevel: boolean;
  onNextLevel: () => void;
  onReplay: () => void;
  onMainMenu: () => void;
}

export function VictoryModal({
  level,
  score,
  coins,
  stars,
  hasNextLevel,
  onNextLevel,
  onReplay,
  onMainMenu,
}: VictoryModalProps) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
      <div className="bg-slate-900 border border-amber-500/50 rounded-2xl max-w-md w-full p-6 sm:p-8 shadow-2xl text-center relative overflow-hidden">
        {/* Glow Header Accent */}
        <div className="absolute top-0 inset-x-0 h-1.5 bg-gradient-to-r from-amber-400 via-amber-300 to-amber-500" />

        <div className="w-12 h-12 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center mx-auto mb-3 shadow-inner">
          <Trophy className="w-6 h-6" />
        </div>

        <h2 className="text-2xl sm:text-3xl font-black text-white font-display tracking-tight">
          LEVEL COMPLETE!
        </h2>
        <div className="text-xs font-bold text-amber-400 mt-0.5 uppercase tracking-wider">
          {level.name}
        </div>

        {/* 3-Star Rating Animation */}
        <div className="flex items-center justify-center gap-2 my-5">
          {[1, 2, 3].map((starNum) => (
            <div
              key={starNum}
              className={`p-2 rounded-xl transition-all duration-500 ${
                starNum <= stars
                  ? 'bg-amber-500/20 border border-amber-400/60 scale-110 shadow-lg shadow-amber-500/20'
                  : 'bg-slate-800 border border-slate-700/60 opacity-40'
              }`}
            >
              <Star
                className={`w-7 h-7 ${
                  starNum <= stars
                    ? 'text-amber-400 fill-amber-400'
                    : 'text-slate-600'
                }`}
              />
            </div>
          ))}
        </div>

        {/* Level Reward Summary */}
        <div className="bg-slate-800/80 rounded-xl p-3.5 border border-slate-700/60 mb-6 text-left">
          <div className="flex items-center justify-between text-xs py-1">
            <span className="text-slate-400">Total Run Score</span>
            <span className="font-bold text-white tabular-nums">{score.toLocaleString()}</span>
          </div>
          <div className="flex items-center justify-between text-xs py-1">
            <span className="text-slate-400">$SQUEEK Earned</span>
            <span className="font-bold text-amber-300 tabular-nums">+{coins}</span>
          </div>
          <div className="flex items-center justify-between text-xs py-1 border-t border-slate-700/50 mt-1 pt-2">
            <span className="text-amber-400 font-bold flex items-center gap-1">
              <Coins className="w-3.5 h-3.5" />
              <span>Completion Bonus</span>
            </span>
            <span className="font-black text-amber-300 tabular-nums">+100 $SQUEEK</span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="space-y-2.5">
          {hasNextLevel ? (
            <button
              type="button"
              onClick={onNextLevel}
              className="w-full py-3 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-sm uppercase tracking-wider flex items-center justify-center gap-2 transition-all active:scale-95 shadow-lg shadow-amber-500/25 cursor-pointer"
            >
              <span>NEXT LEVEL</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          ) : (
            <button
              type="button"
              onClick={onMainMenu}
              className="w-full py-3 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-sm uppercase tracking-wider flex items-center justify-center gap-2 transition-all active:scale-95 shadow-lg shadow-amber-500/25 cursor-pointer"
            >
              <span>YOU CONQUERED ALL LEVELS!</span>
            </button>
          )}

          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={onReplay}
              className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
            >
              <RotateCcw className="w-4 h-4 text-slate-400" />
              <span>Replay</span>
            </button>

            <button
              type="button"
              onClick={onMainMenu}
              className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
            >
              <Home className="w-4 h-4 text-slate-400" />
              <span>Main Menu</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
