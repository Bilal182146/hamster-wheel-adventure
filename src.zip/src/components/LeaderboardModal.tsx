import { LeaderboardEntry } from '../types/game';
import { Trophy, Medal, X, Flame } from 'lucide-react';

interface LeaderboardModalProps {
  entries: LeaderboardEntry[];
  playerScore: number;
  onClose: () => void;
}

export function LeaderboardModal({
  entries,
  playerScore,
  onClose,
}: LeaderboardModalProps) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div className="bg-slate-900 border border-slate-700/80 rounded-2xl max-w-xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <Trophy className="w-5 h-5 text-amber-400" />
            <div>
              <h2 className="text-xl font-black text-white font-display">SQUEEKCHAIN LEADERBOARD</h2>
              <p className="text-xs text-slate-400">Top wheel runners across the community ledger</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-lg bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Player Snapshot Banner */}
        <div className="px-6 py-3 bg-amber-500/10 border-b border-amber-500/20 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2 text-amber-300 font-semibold">
            <Flame className="w-4 h-4 text-amber-400" />
            <span>Your Personal Best:</span>
          </div>
          <div className="text-amber-200 font-black tabular-nums font-display text-sm">
            {playerScore.toLocaleString()} pts
          </div>
        </div>

        {/* Leaderboard Table */}
        <div className="p-6 overflow-y-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 uppercase tracking-wider font-semibold">
                <th className="pb-3 w-12">Rank</th>
                <th className="pb-3">Hamster Runner</th>
                <th className="pb-3 text-right">Distance</th>
                <th className="pb-3 text-right">Score</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {entries.map((entry) => {
                const isTop1 = entry.rank === 1;
                const isTop2 = entry.rank === 2;
                const isTop3 = entry.rank === 3;
                const isPlayer = entry.isPlayer;

                return (
                  <tr
                    key={entry.rank}
                    className={`transition-colors ${
                      isPlayer
                        ? 'bg-amber-500/15 font-bold text-amber-200'
                        : 'text-slate-300 hover:bg-slate-800/40'
                    }`}
                  >
                    <td className="py-3 font-display">
                      {isTop1 ? (
                        <span className="flex items-center justify-center w-6 h-6 rounded-full bg-amber-500 text-slate-950 font-black text-xs">
                          1
                        </span>
                      ) : isTop2 ? (
                        <span className="flex items-center justify-center w-6 h-6 rounded-full bg-slate-300 text-slate-950 font-black text-xs">
                          2
                        </span>
                      ) : isTop3 ? (
                        <span className="flex items-center justify-center w-6 h-6 rounded-full bg-amber-700 text-white font-black text-xs">
                          3
                        </span>
                      ) : (
                        <span className="text-slate-500 font-mono pl-1.5 tabular-nums">
                          #{entry.rank}
                        </span>
                      )}
                    </td>

                    <td className="py-3">
                      <div className="flex items-center gap-2">
                        <span className={isPlayer ? 'text-amber-300 font-bold' : 'text-white font-medium'}>
                          {entry.username}
                        </span>
                        {isPlayer && (
                          <span className="text-[10px] bg-amber-400 text-slate-950 px-1 rounded font-black">
                            YOU
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-slate-500 mt-0.5 flex items-center gap-1.5">
                        <span>{entry.skinName}</span>
                        <span aria-hidden="true">·</span>
                        <span>{entry.coins} $SQUEEK</span>
                      </div>
                    </td>

                    <td className="py-3 text-right font-mono tabular-nums text-slate-400">
                      {entry.distance}m
                    </td>

                    <td className="py-3 text-right font-mono font-bold tabular-nums text-amber-300 text-sm">
                      {entry.score.toLocaleString()}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
