import { RotateCcw, Home, Shirt, Flame, Coins, Trophy } from 'lucide-react';

interface GameOverModalProps {
  score: number;
  distance: number;
  coins: number;
  comboPeak: number;
  isNewHighScore: boolean;
  onRestart: () => void;
  onOpenLocker: () => void;
  onMainMenu: () => void;
}

export function GameOverModal({
  score,
  distance,
  coins,
  comboPeak,
  isNewHighScore,
  onRestart,
  onOpenLocker,
  onMainMenu,
}: GameOverModalProps) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
      <div className="bg-slate-900 border border-slate-700/80 rounded-2xl max-w-md w-full p-6 sm:p-8 shadow-2xl text-center relative overflow-hidden">
        {/* Top Accent Light */}
        <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-rose-500 via-amber-500 to-rose-500" />

        {/* High Score Banner */}
        {isNewHighScore && (
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/20 border border-amber-400/50 text-amber-300 text-xs font-black uppercase tracking-wider mb-3 animate-bounce">
            <Trophy className="w-3.5 h-3.5 text-amber-400" />
            <span>New Personal Best!</span>
          </div>
        )}

        <h2 className="text-2xl sm:text-3xl font-black text-white font-display tracking-tight">
          WHEEL STOPPED!
        </h2>
        <p className="text-xs text-slate-400 mt-1 mb-6">
          The hamster took a tumble, but the SqueekChain adventure rolls on!
        </p>

        {/* Performance Metrics Bento */}
        <div className="grid grid-cols-2 gap-3 mb-6">
          {/* Final Score */}
          <div className="p-3 bg-slate-800/80 rounded-xl border border-slate-700/60 text-left">
            <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Final Score</div>
            <div className="text-xl font-black text-amber-300 font-display tabular-nums mt-0.5">
              {score.toLocaleString()}
            </div>
          </div>

          {/* Distance */}
          <div className="p-3 bg-slate-800/80 rounded-xl border border-slate-700/60 text-left">
            <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Distance Run</div>
            <div className="text-xl font-black text-white font-display tabular-nums mt-0.5">
              {distance}m
            </div>
          </div>

          {/* $SQUEEK Coins */}
          <div className="p-3 bg-slate-800/80 rounded-xl border border-slate-700/60 text-left flex items-center gap-2">
            <Coins className="w-6 h-6 text-amber-400 shrink-0" />
            <div>
              <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">$SQUEEK Earned</div>
              <div className="text-lg font-black text-amber-300 font-display tabular-nums">
                +{coins}
              </div>
            </div>
          </div>

          {/* Peak Combo */}
          <div className="p-3 bg-slate-800/80 rounded-xl border border-slate-700/60 text-left flex items-center gap-2">
            <Flame className="w-6 h-6 text-rose-500 shrink-0" />
            <div>
              <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Peak Combo</div>
              <div className="text-lg font-black text-rose-300 font-display tabular-nums">
                {comboPeak}X
              </div>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="space-y-2.5">
          <button
            type="button"
            onClick={onRestart}
            className="w-full py-3 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-sm uppercase tracking-wider flex items-center justify-center gap-2 transition-all active:scale-95 shadow-lg shadow-amber-500/25 cursor-pointer"
          >
            <RotateCcw className="w-4 h-4 stroke-[2.5]" />
            <span>PLAY AGAIN</span>
          </button>

          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={onOpenLocker}
              className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
            >
              <Shirt className="w-4 h-4 text-amber-400" />
              <span>Squeek Locker</span>
            </button>

            <button
              type="button"
              onClick={onMainMenu}
              className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
            >
              <Home className="w-4 h-4 text-slate-400" />
              <span>Main Menu</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
