import { useState } from 'react';
import { Play, Infinity as InfinityIcon, Shirt, Trophy, Award, HelpCircle, Volume2, VolumeX, Music } from 'lucide-react';
import { PlayerStats, HamsterSkin } from '../types/game';

interface TitleScreenProps {
  stats: PlayerStats;
  currentSkin: HamsterSkin;
  onPlayAdventure: () => void;
  onPlayEndless: () => void;
  onOpenLocker: () => void;
  onOpenLeaderboard: () => void;
  onOpenAchievements: () => void;
  onToggleSound: () => void;
  onToggleMusic: () => void;
}

export function TitleScreen({
  stats,
  currentSkin,
  onPlayAdventure,
  onPlayEndless,
  onOpenLocker,
  onOpenLeaderboard,
  onOpenAchievements,
  onToggleSound,
  onToggleMusic,
}: TitleScreenProps) {
  const [showHowToPlay, setShowHowToPlay] = useState(false);

  return (
    <div className="relative w-full h-full min-h-[560px] flex flex-col justify-between overflow-y-auto bg-slate-950 text-slate-100 p-4 sm:p-6 lg:p-8">
      {/* Background Decorative Glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-4xl h-96 bg-gradient-to-b from-amber-500/10 via-amber-600/5 to-transparent blur-3xl pointer-events-none" />

      {/* Top Bar with SqueekChain Stats & Audio Toggles */}
      <div className="relative z-10 flex items-center justify-between gap-4 w-full max-w-5xl mx-auto">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full overflow-hidden border border-amber-400/50 shadow-md bg-amber-500/20 shrink-0">
            <img
              src="/src/assets/images/hamster_mascot_avatar_1793984642574.jpg"
              alt="SqueekChain Hamster Mascot"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
              onError={(e) => {
                // Resilient CSS fallback per Section 3.E
                (e.target as HTMLElement).style.display = 'none';
              }}
            />
          </div>
          <div>
            <div className="text-xs uppercase tracking-wider text-amber-400 font-bold">SqueekChain Community</div>
            <div className="text-xs text-slate-400">Hamster Wheel Adventure</div>
          </div>
        </div>

        {/* Player Token Bank & Controls */}
        <div className="flex items-center gap-2 sm:gap-3">
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900/80 border border-amber-500/30 text-amber-300 font-bold text-xs sm:text-sm">
            <span>🪙</span>
            <span className="tabular-nums">{stats.totalCoins}</span>
            <span className="text-[10px] text-amber-500 font-bold hidden sm:inline">$SQUEEK</span>
          </div>

          {/* Sound Toggle */}
          <button
            type="button"
            onClick={onToggleSound}
            aria-label={stats.soundEnabled ? 'Mute Sound' : 'Enable Sound'}
            className="w-9 h-9 rounded-xl bg-slate-900/80 border border-slate-700/60 flex items-center justify-center text-slate-300 hover:text-white hover:bg-slate-800 transition-colors"
          >
            {stats.soundEnabled ? <Volume2 className="w-4 h-4 text-amber-400" /> : <VolumeX className="w-4 h-4 text-slate-500" />}
          </button>

          {/* Music Toggle */}
          <button
            type="button"
            onClick={onToggleMusic}
            aria-label={stats.musicEnabled ? 'Disable Music' : 'Enable Music'}
            className="w-9 h-9 rounded-xl bg-slate-900/80 border border-slate-700/60 flex items-center justify-center text-slate-300 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <Music className={`w-4 h-4 ${stats.musicEnabled ? 'text-amber-400' : 'text-slate-500'}`} />
          </button>
        </div>
      </div>

      {/* Main Hero & Character Showcase */}
      <div className="relative z-10 w-full max-w-4xl mx-auto my-auto py-6 sm:py-8 flex flex-col items-center text-center">
        {/* Hero Artwork Card */}
        <div className="relative w-full max-w-md sm:max-w-xl aspect-[16/9] rounded-2xl overflow-hidden border border-amber-500/30 shadow-2xl shadow-amber-500/10 mb-6 group">
          <img
            src="/src/assets/images/hamster_hero_banner_1793984645016.jpg"
            alt="Hamster Wheel Adventure Gameplay Hero"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
            onError={(e) => {
              (e.target as HTMLElement).style.display = 'none';
            }}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent flex flex-col justify-end p-4 sm:p-6 text-left">
            <div className="text-xs font-bold text-amber-300 uppercase tracking-widest">Official SqueekChain Game</div>
            <h1 className="text-2xl sm:text-4xl font-black text-white tracking-tight font-display drop-shadow-md">
              HAMSTER WHEEL ADVENTURE
            </h1>
            <p className="text-xs sm:text-sm text-slate-200 mt-1 line-clamp-2 max-w-md">
              Spin the wheel, leap over obstacles, duck under lasers, and collect golden $SQUEEK tokens!
            </p>
          </div>
        </div>

        {/* Selected Hamster Skin Preview Badge */}
        <div className="flex items-center gap-2 mb-6 text-xs text-slate-400">
          <span>Equipped Runner:</span>
          <span className="font-bold text-amber-400">{currentSkin.name}</span>
          <span aria-hidden="true">·</span>
          <span>High Score:</span>
          <span className="font-bold text-amber-300 tabular-nums">{stats.highestScore.toLocaleString()}</span>
        </div>

        {/* Primary Action Buttons */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 w-full max-w-md">
          {/* Adventure Mode */}
          <button
            type="button"
            onClick={onPlayAdventure}
            className="flex items-center justify-center gap-3 py-3.5 px-6 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-black text-base hover:from-amber-400 hover:to-amber-500 transition-all shadow-lg shadow-amber-500/25 active:scale-95 cursor-pointer"
          >
            <Play className="w-5 h-5 fill-current" />
            <span>LEVEL ADVENTURE</span>
          </button>

          {/* Endless Runner Mode */}
          <button
            type="button"
            onClick={onPlayEndless}
            className="flex items-center justify-center gap-3 py-3.5 px-6 rounded-xl bg-slate-900 border border-slate-700/80 hover:border-amber-400/50 hover:bg-slate-800 text-white font-bold text-base transition-all active:scale-95 cursor-pointer"
          >
            <InfinityIcon className="w-5 h-5 text-amber-400" />
            <span>ENDLESS RUNNER</span>
          </button>
        </div>

        {/* Secondary Navigation Options */}
        <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-3 mt-4 w-full max-w-md">
          <button
            type="button"
            onClick={onOpenLocker}
            className="flex items-center gap-2 px-3.5 py-2 rounded-lg bg-slate-900/80 border border-slate-800 hover:border-slate-700 text-xs font-semibold text-slate-300 hover:text-white transition-colors"
          >
            <Shirt className="w-4 h-4 text-amber-400" />
            <span>Squeek Locker</span>
          </button>

          <button
            type="button"
            onClick={onOpenLeaderboard}
            className="flex items-center gap-2 px-3.5 py-2 rounded-lg bg-slate-900/80 border border-slate-800 hover:border-slate-700 text-xs font-semibold text-slate-300 hover:text-white transition-colors"
          >
            <Trophy className="w-4 h-4 text-amber-400" />
            <span>Leaderboard</span>
          </button>

          <button
            type="button"
            onClick={onOpenAchievements}
            className="flex items-center gap-2 px-3.5 py-2 rounded-lg bg-slate-900/80 border border-slate-800 hover:border-slate-700 text-xs font-semibold text-slate-300 hover:text-white transition-colors"
          >
            <Award className="w-4 h-4 text-amber-400" />
            <span>Achievements</span>
          </button>

          <button
            type="button"
            onClick={() => setShowHowToPlay(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-slate-900/80 border border-slate-800 hover:border-slate-700 text-xs font-semibold text-slate-300 hover:text-white transition-colors"
          >
            <HelpCircle className="w-4 h-4 text-amber-400" />
            <span>How to Play</span>
          </button>
        </div>
      </div>

      {/* Footer Info */}
      <div className="relative z-10 text-center text-xs text-slate-400 max-w-lg mx-auto pt-2">
        <span>SqueekChain Community Edition · Tap anywhere or use Spacebar to Jump · Swipe down or press Roll to Duck</span>
      </div>

      {/* How To Play Modal */}
      {showHowToPlay && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
          <div className="bg-slate-900 border border-slate-700/80 rounded-2xl max-w-md w-full p-6 shadow-2xl relative">
            <h3 className="text-xl font-black text-white font-display mb-4">HOW TO PLAY</h3>

            <div className="space-y-3.5 text-xs text-slate-300">
              <div className="flex items-start gap-3 bg-slate-800/60 p-3 rounded-xl border border-slate-700/40">
                <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-sm shrink-0">
                  ↑
                </div>
                <div>
                  <div className="font-bold text-white text-sm">Jump & Double Jump</div>
                  <div className="text-slate-400 mt-0.5">
                    Tap the screen, press the <span className="text-amber-400 font-semibold">JUMP</span> button, or hit Spacebar. Tap again in mid-air to perform an acrobatic spin flip!
                  </div>
                </div>
              </div>

              <div className="flex items-start gap-3 bg-slate-800/60 p-3 rounded-xl border border-slate-700/40">
                <div className="w-8 h-8 rounded-lg bg-sky-500/20 text-sky-400 flex items-center justify-center font-bold text-sm shrink-0">
                  ↓
                </div>
                <div>
                  <div className="font-bold text-white text-sm">Roll & Duck Under Pipes</div>
                  <div className="text-slate-400 mt-0.5">
                    Swipe down, press the <span className="text-sky-400 font-semibold">ROLL</span> button, or press the Down Arrow to curl into a speedy hamster ball and slip under low hazards.
                  </div>
                </div>
              </div>

              <div className="flex items-start gap-3 bg-slate-800/60 p-3 rounded-xl border border-slate-700/40">
                <div className="w-8 h-8 rounded-lg bg-rose-500/20 text-rose-400 flex items-center justify-center font-bold text-sm shrink-0">
                  ⚡
                </div>
                <div>
                  <div className="font-bold text-white text-sm">Power-Ups & Combos</div>
                  <div className="text-slate-400 mt-0.5">
                    Grab Magnets 🧲, Turbo Speed ⚡, Bubble Shields 🛡️, and 2X $SQUEEK Multipliers. Consecutive coin pickups multiply your score up to 10X!
                  </div>
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setShowHowToPlay(false)}
              className="w-full mt-6 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-sm transition-colors cursor-pointer"
            >
              GOT IT, LET'S ROLL!
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
